package com.example.ch15_network;

import android.app.Application;

import com.example.ch15_network.network.NetworkService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyApplication extends Application {
    public String API_KEY = "079dac74a5f94ebdb990ecf61c8854b7";
    public NetworkService networkService;

    public MyApplication(){
        Retrofit.Builder builder = new Retrofit.Builder();
        builder.baseUrl("https://newsapi.org");
        builder.addConverterFactory(GsonConverterFactory.create());
        networkService = builder.build().create(NetworkService.class);
    }
}
