package com.example.ch15_network.network;

public class News {
    long id;
    String author;
    String title;
    String description;
    String urlToImage;
    String publishedAt;
}
