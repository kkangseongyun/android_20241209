package com.example.ch15_network.network;

import java.util.ArrayList;

public class Page {
    public ArrayList<News> articles;
}
