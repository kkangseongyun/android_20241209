package com.example.ch15_network.network;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ch15_network.MyApplication;
import com.example.ch15_network.databinding.ItemNewsBinding;

import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//복사해서 작성................
class MyNewsViewHolder extends RecyclerView.ViewHolder {
    ItemNewsBinding binding;

    MyNewsViewHolder(ItemNewsBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
    }
}

public class MyAdapter extends RecyclerView.Adapter<MyNewsViewHolder> {
    ArrayList<News> datas;
    MyApplication application;

    public MyAdapter(MyApplication application, ArrayList<News> datas) {
        this.application = application;
        this.datas = datas;
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @NonNull
    @Override
    public MyNewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyNewsViewHolder(ItemNewsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyNewsViewHolder holder, int position) {

        //add......................................

        News news = datas.get(position);

        holder.binding.itemTitle.setText(news.title);
        holder.binding.itemDesc.setText(news.description);
        holder.binding.itemTime.setText(news.author + " At " + news.publishedAt);
        if (news.urlToImage != null) {
            Call<ResponseBody> avatarImageCall = application.networkService.getNetworkImage(news.urlToImage);
            avatarImageCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if (response.isSuccessful()) {
                        if (response.body() != null) {
                            Bitmap bitmap = BitmapFactory.decodeStream(response.body().byteStream());
                            holder.binding.itemImage.setImageBitmap(bitmap);
                        }
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {

                }

            });
        }
    }

}
