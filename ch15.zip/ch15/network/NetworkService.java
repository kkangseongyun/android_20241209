package com.example.ch15_network.network;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface NetworkService {
    @GET("/v2/everything")
    public Call<Page> getList(
            @Query("q") String q,
            @Query("apiKey") String apiKey,
            @Query("page") long page,
            @Query("pageSize") int pageSize
    );

    @GET
    Call<ResponseBody> getNetworkImage(@Url String url);
}
